package com.example.PrjRafael.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.PrjRafael.entidades.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

}
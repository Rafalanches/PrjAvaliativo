package com.example.PrjRafael.entidades;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="pedido")
public class Pedido {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long id;

	private Date Data_pedido;

	private double Valor_total;
	
	public Pedido() {
		
	}
	
	public Pedido(Long id, Date Data_pedido, double Valor_total) {
		super();
		this.id = id;
		this.Data_pedido = Data_pedido;
		this.Valor_total = Valor_total;

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getData_pedido() {
		return Data_pedido;
	}

	public void setData_pedido(Date data_pedido) {
		Data_pedido = data_pedido;
	}

	public double getValor_total() {
		return Valor_total;
	}

	public void setValor_total(double valor_total) {
		Valor_total = valor_total;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_fornecedor", nullable = false)
	private Fornecedor fornecedor;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_cliente", nullable = false)
	private Cliente cliente;

}

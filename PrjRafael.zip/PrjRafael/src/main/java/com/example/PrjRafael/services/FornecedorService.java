package com.example.PrjRafael.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PrjRafael.entidades.Fornecedor;
import com.example.PrjRafael.repositories.FornecedorRepository;

@Service
public class FornecedorService {

	@Autowired
	private FornecedorRepository fornecedorRepository;

	public List<Fornecedor> getAllFornecedores() {
		return fornecedorRepository.findAll();
	}

	public Fornecedor getFornecedorById(long forcodigo) {
		return fornecedorRepository.findById(forcodigo).orElse(null);
	}

	public Fornecedor saveFornecedor(Fornecedor fornecedor) {
		return fornecedorRepository.save(fornecedor);
	}
}

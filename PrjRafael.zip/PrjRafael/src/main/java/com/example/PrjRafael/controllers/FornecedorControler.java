package com.example.PrjRafael.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.PrjRafael.entidades.Fornecedor;
import com.example.PrjRafael.services.FornecedorService;

@RestController
@RequestMapping("/fornecedor")
public class FornecedorControler {

	private final FornecedorService fornecedorService;

	@Autowired
	public FornecedorControler(FornecedorService fornecedorService) {
		this.fornecedorService = fornecedorService;
	}

	@GetMapping("/{id}")
	public ResponseEntity<Fornecedor> findFornecedorbyId(@PathVariable Long id) {
		Fornecedor fornecedor = fornecedorService.getFornecedorById(id);
		if (fornecedor != null) {
			return ResponseEntity.ok(fornecedor);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("/")
	public ResponseEntity<List<Fornecedor>> findAllUsuariocontrol() {
		List<Fornecedor> fornecedor = fornecedorService.getAllFornecedores();
		return ResponseEntity.ok(fornecedor);
	}

	@PostMapping("/")
	public ResponseEntity<Fornecedor> insertUsuarioControl(@RequestBody Fornecedor fornecedor) {
		Fornecedor novoFornecedor = fornecedorService.saveFornecedor(fornecedor);
		return ResponseEntity.status(HttpStatus.CREATED).body(novoFornecedor);
	}

}

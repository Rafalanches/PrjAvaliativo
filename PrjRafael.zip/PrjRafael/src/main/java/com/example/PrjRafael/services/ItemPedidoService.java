package com.example.PrjRafael.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PrjRafael.entidades.ItemPedido;
import com.example.PrjRafael.repositories.ItemPedidoRepository;

@Service
public class ItemPedidoService {

	@Autowired
	private ItemPedidoRepository itemPedidoRepository;

	public List<ItemPedido> getAllItemPedido() {
		return itemPedidoRepository.findAll();
	}

	public ItemPedido getItemPedidoById(long itempcodigo) {
		return itemPedidoRepository.findById(itempcodigo).orElse(null);
	}

	public ItemPedido saveItemPedido(ItemPedido itemPedido) {
		return itemPedidoRepository.save(itemPedido);
	}

}

package com.example.PrjRafael.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.PrjRafael.entidades.Fornecedor;

public interface FornecedorRepository extends JpaRepository<Fornecedor, Long> {

}

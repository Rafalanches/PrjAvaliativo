package com.example.PrjRafael;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjRafaelApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjRafaelApplication.class, args);
	}

}

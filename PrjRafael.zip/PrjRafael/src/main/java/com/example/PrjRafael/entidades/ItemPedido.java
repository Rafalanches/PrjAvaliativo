package com.example.PrjRafael.entidades;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="itempedido")
public class ItemPedido {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long id;

	private Integer Quantidade;

	private double Valor_unitario;
	
	public ItemPedido() {
		
	}
	
	public ItemPedido(Long id, Integer Quantidade, double Valor_unitario) {
		super();
		this.id = id;
		this.Quantidade = Quantidade;
		this.Valor_unitario = Valor_unitario;

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getQuantidade() {
		return Quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		Quantidade = quantidade;
	}

	public double getValor_unitario() {
		return Valor_unitario;
	}

	public void setValor_unitario(double valor_unitario) {
		Valor_unitario = valor_unitario;
	}
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_pedido", nullable = false)
	private Pedido pedido;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_produto", nullable = false)
	private Produto produto;

}

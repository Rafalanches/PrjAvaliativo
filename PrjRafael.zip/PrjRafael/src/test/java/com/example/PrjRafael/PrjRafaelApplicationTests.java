package com.example.PrjRafael;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjRafaelApplicationTests {

	@Test
	void contextLoads() {
	}

}
